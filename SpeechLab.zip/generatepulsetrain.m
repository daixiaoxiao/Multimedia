fs=10000;        % sampling frequency in Hz
duration=0.1;     % duration of the signal in sec.
F0=120;         % fundamental frequency in Hz
M=round(fs/F0);
u_art=zeros(round(duration*fs),1);
for i=1:M:round(duration*fs)
    u_art(i)=1;
end