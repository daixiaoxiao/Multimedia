
[y,Fs] = audioread('s.wav');
% sound(y,Fs);
disp(Fs);
y = resample(y,8000,Fs);
y = y(:,1);
frag = y(14001:14800);
% soundsc(frag);
x = linspace(0,0.1,800);

figure(1)
plot(x,frag);
ylabel('amplitude');
xlabel('time(s)');
print(1, '-dpng', 'u_time_domain');

% period of signal 0.0083s 
f = double(1 / 0.0083);
disp(f);

% Fourier Transform
X = fft(frag);
amp_dB = 20 * log10(abs(X));
amp_dB = amp_dB(1:400);
x = linspace(0,3999,400);

figure(2)
plot(x, amp_dB);
ylabel('amplitude(dB)');
xlabel('frequency(Hz)');
print(2, '-dpng', 'u_frequency_domain');

a = lpc(frag,2);
[h,f]=freqz(1,a,512,8000);

a = lpc(frag,4);
[h1,f1]=freqz(1,a,512,8000);

a = lpc(frag,8);
[h2,f2]=freqz(1,a,512,8000);

a = lpc(frag,12);
[h3,f3]=freqz(1,a,512,8000);

a = lpc(frag,40);
[h4,f4]=freqz(1,a,512,8000);

figure(3)
plot(x, amp_dB, f, 20*log10(abs(h)),'--',f1,20*log10(abs(h1)),'g',f2,20*log10(abs(h2)),'c',f3,20*log10(abs(h3)),'b',f4,20*log10(abs(h4)),'--k');         
ylabel('amplitude(dB)');
xlabel('frequency(Hz)');
% legend('Spectrum', 'LPC N=40');
legend('Spectrum','LPC N=2','LPC N=4','LPC N=8','LPC N=12','LPC N=40');
print(3, '-dpng', 'u_filterOrder');

a = lpc(frag,12);
est_frag = filter(a,1,frag);
x0 = linspace(0,0.1,800);

X_est = 20*log10(abs(fft(est_frag)));
X_est = X_est(1:400);
x1 = linspace(0,3999,400);
% e = frag-est_frag;

% [acs,lags] = xcorr(e,'coeff');
figure(4)
plot(x0,est_frag,'--'), grid
ylabel('amplitude');
xlabel('time(s)');
print(4, '-dpng', 'u_time_domain_source');

figure(5)
plot(x1,X_est),grid
ylabel('amplitude(dB)');
xlabel('frequency(Hz)');
print(5, '-dpng', 'u_frequency_domain_source');

generatepulsetrain; %call the generatepulsetrain m file
a = lpc(frag,12);
x_art = filter(1,a,u_art);
X_art = 20*log10(abs(fft(x_art)));
X_art = X_art(1:500);
x0 = linspace(0,0.1,1000);
x1 = linspace(0,3999,500);
soundsc(x_art);
figure(6)
ax1 = subplot(2,1,1); % top subplot
ax2 = subplot(2,1,2); % bottom subplot

plot(ax1,x0,x_art);
title(ax1,'Time domain')
ylabel(ax1,'amplitude')

plot(ax2,x1,X_art);
title(ax2,'Frequency Spectrum')
ylabel(ax2,'amplitude(dB)')
print(6, '-dpng', 'u_art[k]');

